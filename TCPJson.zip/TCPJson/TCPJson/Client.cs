﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace TCPJson
{
    public class Client
    {
        public async Task HandleClient(TcpClient socket)
        {
            using NetworkStream ns = socket.GetStream();
            using StreamReader reader = new StreamReader(ns);
            using StreamWriter writer = new StreamWriter(ns) { AutoFlush = true };
            // github solution says use AutoFlush

            bool keepListening = true;

            while (keepListening && socket.Connected)
            {
                try
                {
                    string message = await reader.ReadLineAsync();
                    if (message == null) break;

                    try
                    {
                        // split the strings and put each the entries in an array. Removeemptyentries removes spaces.
                        string[] parts = message.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                        // converts string to lowercase, cos our methods are in lowercase
                        string method = parts[0].ToLower();
                        // try parse again to convert to INT, we put it in a if state also ! so we can throw exception
                        // parts[1] because here parts[0] is our command(add, subtract etc), so parts[1] is our first number.
                        if (!int.TryParse(parts[1], out int num1) || !int.TryParse(parts[2], out int num2))
                        {
                            throw new InvalidOperationException("num1 and num2 must be int.");
                        }

                        // switch state from which method was used.
                        int result = method switch
                        {
                            "add" => Add(num1, num2),
                            "subtract" => Subtract(num1, num2),
                            "random" => Random(num1, num2)
                        };

                        // returns result in json format
                        var jsonResponse = new JsonResponse { Result = result };
                        await writer.WriteLineAsync(JsonSerializer.Serialize(jsonResponse));
                    }
                    catch (Exception ex)
                    {
                        // returns an error also in json format
                        var errorResponse = new JsonResponse { Error = ex.Message };
                        await writer.WriteLineAsync(JsonSerializer.Serialize(errorResponse));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                    break;
                }
            }

            socket.Close();
        }
        private bool ValidateJsonRequest(JsonRequest request)
        {
            // Check for string and returns if not null
            // this is mostly for error handling
            return !string.IsNullOrWhiteSpace(request.Method) && request.Tal1 != null && request.Tal2 != null;
        }

        static int Add(int n1, int n2)
        {
            return n1 + n2;
        }
        static int Subtract(int n1, int n2)
        {
            return n1 - n2; ;
        }
        static int Random(int n1, int n2)
        {
            var result = 0;
            return result = RandomNumberGenerator.Generate(n1, n2);
            // this was from the first semester called DiceGame.
        }
    }
}
