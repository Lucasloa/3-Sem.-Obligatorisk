﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCPJson
{
    public class JsonRequest
    {
        public string Method { get; set; }
        public int Tal1 { get; set; }
        public int Tal2 { get; set; }
    }
}
