﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opg4TCP
{
    public class RandomNumberGenerator
    {
        private static Random _random = new Random();

        public static int Generate(int n1, int n2)
        {
            return _random.Next(n1, n2);
        }
    }
}
