﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Opg4TCP
{
    public class Client
    {
        public void HandleClient(TcpClient socket)
        {

            // Read and write TO the connection via streams.
            NetworkStream ns = socket.GetStream();
            // These get split into 2 streams, a reader and a writer
            StreamReader reader = new StreamReader(ns);
            StreamWriter writer = new StreamWriter(ns);

            //We don't want the server to be stuck in an infinite loop, so we need a way to end the loop
            //this is what we will use this bool variable for
            bool keepListening = true;
            //In order for the server to be able to handle more than one client a while loop is needed.
            //here it is while true, because we don't have something that tells it to stop

            // a variable to find out what command we're on
            var currentcommand = "";
            // need a numbers to overwrite and save.
            int? number1 = null;
            // gonna use this for the json part.
            int? number2 = null;

            // THESE have to be outside the loop to work, else they get reset everytime

            // we add a socket.Connected to make sure the user is still in the server.
            while (keepListening && socket.Connected)
            {
                //Here it reads all data send until a line break (cr lf) is received; notice the Line part of the ReadLine
                string message = reader.ReadLine();
                //Here it writes the received data to the Console
                //this is only for testing purposes, to verify that the server recieves the data
                //Console.WriteLine($"This is only visible to the console: {message}");

                //THIS IS WITHOUT THE METHODS
                writer.WriteLine(message);


                writer.Flush();
                // flush should be used afterwards everytime.

                string[] input = message.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                // we have to make an array of the words and then split each word to properly find the command
                // we did the same thing in Visual Studio Code before this





                // if statement to close the connection.
                if (message.Equals("close", StringComparison.OrdinalIgnoreCase))
                {
                    keepListening = false;
                }
                #region Add method
                if (message.Equals("add", StringComparison.OrdinalIgnoreCase))
                {
                    currentcommand = "add"; 
                    writer.WriteLine("Enter the first number.");
                    writer.Flush();
                    continue;
                }
                if (currentcommand == "add" && number1 == null)
                {
                    //    // TryParse checks if the string "numbers" are integers, then it OUT puts it into num1 which
                    //    // is a local variable. We do this twice to get these two numbers from a string added together.
                    //    // Try parse is a boolean that gives a TRUE statement if it sucessfully converts the string to int
                    if (int.TryParse(message, out int num1))
                    {
                        number1 = num1; // save the result
                        writer.WriteLine("Enter the second number.");
                        writer.Flush();
                    }
                    continue;
                }
                if (currentcommand == "add" && number1 != null)
                {
                    if (int.TryParse(message, out int num2))
                    {

                        int result = Add(number1.Value, num2);
                        writer.WriteLine($"Result: {result}");
                        writer.Flush();

                        // reset the number so we can go again
                        number1 = null;
                        currentcommand = null;
                    }
                }
                #endregion
                #region Subtract method
                if (message.Equals("subtract", StringComparison.OrdinalIgnoreCase))
                {
                    currentcommand = "subtract";
                    writer.WriteLine("Enter the first number.");
                    writer.Flush();
                    continue;
                }
                if (currentcommand == "subtract" && number1 == null)
                {
                    //    // TryParse checks if the string "numbers" are integers, then it OUT puts it into num1 which
                    //    // is a local variable. We do this twice to get these two numbers from a string added together.
                    //    // Try parse is a boolean that gives a TRUE statement if it sucessfully converts the string to int
                    if (int.TryParse(message, out int num1))
                    {
                        number1 = num1; // save the result
                        writer.WriteLine("Enter the second number.");
                        writer.Flush();
                    }
                    continue;
                }
                if (currentcommand == "subtract" && number1 != null)
                {
                    if (int.TryParse(message, out int num2))
                    {

                        int result = Subtract(number1.Value, num2);

                        writer.WriteLine($"Result: {result}");
                        writer.Flush();

                        // reset the number so we can go again
                        number1 = null;
                        currentcommand = null;
                    }

                }
                #endregion
                #region Randomizer method
                if (message.Equals("random", StringComparison.OrdinalIgnoreCase))
                {
                    currentcommand = "random";
                    writer.WriteLine("Enter the first number.");
                    writer.Flush();
                    continue;
                }
                if (currentcommand == "random" && number1 == null)
                {
                    //    // TryParse checks if the string "numbers" are integers, then it OUT puts it into num1 which
                    //    // is a local variable. We do this twice to get these two numbers from a string added together.
                    //    // Try parse is a boolean that gives a TRUE statement if it sucessfully converts the string to int
                    if (int.TryParse(message, out int num1))
                    {
                        number1 = num1; // save the result
                        writer.WriteLine("Enter the second number.");
                        writer.Flush();
                    }
                    continue;
                }
                if (currentcommand == "random" && number1 != null)
                {
                    if (int.TryParse(message, out int num2))
                    {

                        int result = Random(number1.Value, num2);

                        writer.WriteLine($"Result: {result}");
                        writer.Flush();

                        // reset the number so we can go again
                        number1 = null;
                        currentcommand = null;
                    }

                }
                #endregion
                // All methods
                static int Add(int n1, int n2)
                    {
                        return n1 + n2;
                    }
                    static int Subtract(int n1, int n2)
                    {
                        return n1 - n2; ;
                    }
                    static int Random(int n1, int n2)
                    {
                        var result = 0;
                        return result = RandomNumberGenerator.Generate(n1, n2);
                        // this was from the first semester called DiceGame.
                    }

                    // This happens ONCE, 1 message sent, 1 message returned then it ends.
                    //socket.Close();
                    //listener.Stop();

                    //Because it doesn't expect more messages from the client, it closes the socket/connection

                }
                socket.Close();
            }
        }
    }

