﻿using Opg4TCP;
using System;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading.Tasks;
Console.WriteLine("This is the TCP Server:");
Console.WriteLine("Connect via SocketTest with any IP with Port number 7.");
// Initialize object
//Client client = new Client();
TcpListener listener = new TcpListener(IPAddress.Any, 7);
// Begin listening
listener.Start();
// Wait for connection & accept client. Stops until a client is connected
//TcpClient socket = listener.AcceptTcpClient();
// This also returns a a tcpobject.

// a "true" loop added here to constantly check for clients. ALSO creates new client objects
// and each client calls the handleclient method.

while (true)
{
    // Accept a client connection asynchronously to avoid blocking the main thread
    TcpClient socket = await listener.AcceptTcpClientAsync();



    Console.WriteLine("Try the following commands: Random or Add or Subtract.");

    // Handle each client in a separate task
    Task.Run(() =>
    {
        Client clientHandler = new Client();
        clientHandler.HandleClient(socket);
    });
}

//this line will never be reached because of the while loop
//instead it will only stop when the program is stopped
listener.Stop();

